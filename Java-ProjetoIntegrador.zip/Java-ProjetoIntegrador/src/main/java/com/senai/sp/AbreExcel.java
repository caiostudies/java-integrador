package com.senai.sp;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.apache.poi.ss.usermodel.*;

public class AbreExcel {
    //O caminho da planilha
    private static final String fileName = "C:\\Users\\41810782805\\PycharmProjects\\integrado web scraping\\integrador.xlsx";

    static List<Produto> listaProdutos = new ArrayList<>();
    public static void lerExcel(){
        try {
            FileInputStream arquivo = new FileInputStream(new File(AbreExcel.fileName));

            XSSFWorkbook workbook = new XSSFWorkbook(arquivo);
            Sheet sheetProdutos = workbook.getSheetAt(0);

            Iterator<Row> rowIterator = sheetProdutos.iterator();

            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                if (row.getRowNum() == 0){
                    continue;
                } else {
                    Iterator<Cell> cellIterator = row.cellIterator();

                    Produto produto = new Produto();
                    listaProdutos.add(produto);
                    while (cellIterator.hasNext()) {
                        Cell cell = cellIterator.next();
                        switch (cell.getColumnIndex()) {
                            case 0 -> produto.setNome(cell.getStringCellValue());
                            case 1 -> {
                                String precoStr = cell.getStringCellValue();
                                String precoStr2 = precoStr.replace("R$", "").replace(",", ".");
                                double preco = Double.parseDouble(precoStr2);
                                produto.setPreco(preco);
                            }
                        }
                    }
                }
            arquivo.close();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.out.println("Caminho do arquivo excel deve estar incorreto pois não foi encontrado");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
//Exibe todos os produtos
    public static void mostrar_Produtos(){
        Iterator<Produto> itr = listaProdutos.iterator();

        while(itr.hasNext())
        {
            Produto produto = itr.next();
            System.out.printf("%s - R$ %.2f\n", produto.getNome(), produto.getPreco());
        }
    }
    //Exibe o produto com maior preço
    public static void maior_Preco(){
        double maior_Preco = -1;
        String nome = null;
        for (Produto produto:listaProdutos) {
            if (maior_Preco == -1){
                maior_Preco = produto.getPreco();
                nome = produto.getNome();
            } else if (produto.getPreco() > maior_Preco){
                maior_Preco = produto.getPreco();
                nome = produto.getNome();
            }
        }
        System.out.printf("\nO produto mais caro entre eles é:\n%s - R$ %.2f\n", nome, maior_Preco);
    }

    //Exibe o produto com menor preço
    public static void menor_Preco(){
        double menor_Preco = -1;
        String nome = null;
        for (Produto produto:listaProdutos) {
            if (menor_Preco == -1) {
                menor_Preco = produto.getPreco();
                nome = produto.getNome();
            } else if (produto.getPreco() < menor_Preco) {
                menor_Preco = produto.getPreco();
                nome = produto.getNome();
            }
        }
        System.out.printf("\nO produto mais barato entre eles é:\n%s - R$ %.2f\n", nome, menor_Preco);
    }
    //calcula a média entre os preços
    public static void media_Precos(){
        double soma = 0, media = 0;
        for (Produto produto:listaProdutos) {
            soma = soma + produto.getPreco();
        }
        media = soma / listaProdutos.size();
        System.out.printf("\nA média de preço entre os produtos é: R$ %.2f\n", media);
    }

    public static void main(String[] args) {
        lerExcel();
        //Opções do switch case

        while (true) {
            try {
                Scanner entrada = new Scanner(System.in);
                System.out.println("\n-----Olá o que você deseja visualizar do site EA SPORTS-----\n1 - Lista de produtos esportivos\n2 - Maior preço entre os produtos\n3 - Menor preço entre os produtos\n4 - Média de Preço entre os produtos\n5 - Sair\n Digite sua opção:\n");
                int opcao = entrada.nextInt();
                switch (opcao) {
                    case 1 -> mostrar_Produtos();
                    case 2 -> maior_Preco();
                    case 3 -> menor_Preco();
                    case 4 -> media_Precos();
                    case 5 -> System.out.println("Chat finalizado");
                    default -> System.out.println("Opção não encontrada");
                }
                if (opcao == 5) {
                    entrada.close();
                    break;
                }
            } catch (Exception e) {
                System.out.println("Erro " + e);
            }
        }
    }
}
